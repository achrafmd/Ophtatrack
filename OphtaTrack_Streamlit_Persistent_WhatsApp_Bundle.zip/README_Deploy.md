# OphtaTrack — Persistance Google Sheets + Appeler & WhatsApp

Fonctions :
- Appeler en 1 clic (tel:)
- Message WhatsApp en 1 clic (wa.me)
- Données persistantes dans Google Sheets (patients + photos en base64 dans l’onglet Media)

Secrets à ajouter :
APP_PASSWORD = ton_mot_de_passe_optionnel
SHEET_URL = https://docs.google.com/spreadsheets/d/...
GCP_SERVICE_ACCOUNT = {"type":"service_account", ...}
